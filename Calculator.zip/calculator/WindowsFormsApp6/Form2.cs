﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Form2 : Form
    {
        public DialogResult dr;
        public string solution;
        public Form2(List<string> list)
        {
            InitializeComponent();
            foreach (string item in list)
            {
                listBox1.Items.Add(item);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dr = MessageBox.Show("Are you sure, that you want choice a this example?", "Warning!", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if(dr == DialogResult.Yes)
            {
                solution = listBox1.SelectedItem.ToString();
                Close();
                return;
            }
        }
    }
}
