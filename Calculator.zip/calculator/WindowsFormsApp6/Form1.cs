﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using MyParser;

enum Operations
{
    Plus,
    Minus,
    Divide,
    Multiply
}

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        Operations op;
        Lexer lexer;
        Parser parser;
        double result;
        string lastNum;
        List<string> solutionLists = new List<string>();

        bool Enter = false;
        public Form1()
        {
            InitializeComponent();
        }

        //Add num to screen
        void setScreenText(string str)
        {
            textBox1.Text += str;
        }

        void getLastNum()
        {
            lastNum = "";
            string str = textBox1.Text;
            bool isBreak = false;
            for (int i = str.Length-1; i >= 0; i--)
            {
                switch (str[i])
                {
                    case '*':
                        op = Operations.Multiply;
                        isBreak = true;
                        break;
                    case '/':
                        op = Operations.Divide;
                        isBreak = true;
                        break;
                    case '-':
                        op = Operations.Minus;
                        isBreak = true;
                        break;
                    case '+':
                        op = Operations.Plus;
                        isBreak = true;
                        break;
                    default:
                        lastNum += str[i];
                        break;
                }
                if (isBreak) { break; }
            }
            char[] charArray = lastNum.ToCharArray();
            Array.Reverse(charArray);
            lastNum = new string(charArray);
        }
        private void button14_Click(object sender, EventArgs e)
        {
            setScreenText("1");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            setScreenText("2");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            setScreenText("3");
        }

        private void button15_Click(object sender, EventArgs e)
        {
            setScreenText("4");
        }

        private void button12_Click(object sender, EventArgs e)
        {
            setScreenText("5");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            setScreenText("6");
        }

        private void button16_Click(object sender, EventArgs e)
        {
            setScreenText("7");
        }

        private void button13_Click(object sender, EventArgs e)
        {
            setScreenText("8");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            setScreenText("9");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            setScreenText("(");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            setScreenText(")");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            setScreenText("/");
            Enter = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            setScreenText("*");
            Enter = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            setScreenText("-");
            Enter = false;
        }

        private void button19_Click(object sender, EventArgs e)
        {
            setScreenText("+");
            Enter = false;
        }


        //Equal
        /*I attempted to execute the specified function in the calculator application, namely,
         *1+3-2. When the equal button is pressed, the output value is 2. Subsequently,
         *on pressing the equal button again, the calculator performs the last operation
         *(in this instance, subtraction) and deducts the previous number (2)
         *from the current output, resulting in a final value of 0.*/
        private void button7_Click(object sender, EventArgs e)
        {
            if (Enter)
            {
                switch (op)
                {
                    case Operations.Plus:
                        result += int.Parse(lastNum);
                        listBox1.Items.Add($"{textBox1.Text}+{lastNum} = " + result);
                        break;
                    case Operations.Minus:
                        result -= int.Parse(lastNum);
                        listBox1.Items.Add($"{textBox1.Text}-{lastNum} = " + result);
                        break;
                    case Operations.Multiply:
                        result *= int.Parse(lastNum);
                        listBox1.Items.Add($"{textBox1.Text}*{lastNum} = " + result);
                        break;
                    default:
                        result /= int.Parse(lastNum);
                        listBox1.Items.Add($"{textBox1.Text}/{lastNum} = " + result);
                        break;
                }
                textBox1.Text = result.ToString();
            }
            else
            {
                getLastNum();
                lexer = new Lexer(textBox1.Text);
                parser = new Parser(lexer);
                result = parser.ParseAll();
                listBox1.Items.Add(textBox1.Text + " = " + result);
                textBox1.Text = result.ToString();
                Enter = true;
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            setScreenText("0");
        }

        //Clear screen
        private void button20_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            lastNum = "";
            Enter = false;
        }

        //remove one symbol in screen
        private void button17_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != String.Empty)
            {
                textBox1.Text = textBox1.Text.Remove(textBox1.Text.Length - 1);
            }
        }

        //Clear History
        private void button1_Click_1(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }


        //Import example to screen
        private void button21_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Txt Files(*.txt)|*.txt||";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                using (StreamReader sr = new StreamReader(openFileDialog.FileName))
                {
                    while (!sr.EndOfStream)
                    {
                        solutionLists.Add(sr.ReadLine());
                    }
                }
                Form2 f2 = new Form2(solutionLists);
                f2.ShowDialog();
                if (f2.dr == DialogResult.Yes)
                {
                    textBox1.Text = f2.solution;
                }
                solutionLists.Clear();
            }
        }

        //Add the example from history
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string history = listBox1.SelectedItem.ToString();
            textBox1.Text = "";
            foreach (char item in history)
            {
                if(item != ' ') { textBox1.Text += item; }
                else { break; }
            }
            
        }
    }
}
