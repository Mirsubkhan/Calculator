﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyParser
{
    enum TokenType
    {
        Numer,
        Plus,
        Minus,
        Multiply,
        Divide,
        LeftParenteziz,
        RightParenteziz,
        EndOfExpression
    }
    class Token
    {
        public TokenType Type { get; private set; }
        public double Value { get; private set; }

        public Token(TokenType type)
        {
            this.Type = type;
        }

        public Token(TokenType type, double value)
        {
            this.Type = type;
            this.Value = value;
        }
    }
    class Lexer
    {
        private string expression;
        private int position;

        public Lexer(string expression)
        {
            this.expression = expression;
            this.position = 0;
        }

        public Token GetNextToken()
        {
            while (position < expression.Length)
            {
                char c = expression[position];
                if (char.IsDigit(c))
                {
                    double value = 0;
                    while (position < expression.Length && char.IsDigit(expression[position]))
                    {
                        value = value * 10 + (expression[position] - '0');
                        position++;
                    }
                    return new Token(TokenType.Numer, value);
                }
                else if (c == '+')
                {
                    position++;
                    return new Token(TokenType.Plus);
                }
                else if (c == '-')
                {
                    position++;
                    return new Token(TokenType.Minus);
                }
                else if (c == '*')
                {
                    position++;
                    return new Token(TokenType.Multiply);
                }
                else if (c == '/')
                {
                    position++;
                    return new Token(TokenType.Divide);
                }
                else if (c == '(')
                {
                    position++;
                    return new Token(TokenType.LeftParenteziz);
                }
                else if (c == ')')
                {
                    position++;
                    return new Token(TokenType.RightParenteziz);
                }
                else
                {
                    throw new Exception("Unknown Symbol: " + c);
                }
            }
            return new Token(TokenType.EndOfExpression);
        }
    }

    class Parser
    {
        private Lexer lexer;
        public Token currentToken;
        public Parser(Lexer lexer)
        {
            this.lexer = lexer;
            this.currentToken = lexer.GetNextToken();
        }

        private void Eat(TokenType type)
        {
            if (currentToken.Type == type)
            {
                currentToken = lexer.GetNextToken();
            }
            else
            {
                throw new Exception("Unknown Token type" + currentToken.Type);
            }
        }

        private double ParseNumber()
        {
            Token token = currentToken;
            Eat(TokenType.Numer);
            return token.Value;
        }

        private double ParseUnaryMius()
        {
            Eat(TokenType.Minus);
            return -ParseFactor();
        }

        private double ParseParenthezizes()
        {
            Eat(TokenType.LeftParenteziz);
            double result = ParseExpression();
            Eat(TokenType.RightParenteziz);
            return result;
        }

        private double ParseTerm()
        {
            double result = ParseFactor();
            while (currentToken.Type == TokenType.Multiply || currentToken.Type == TokenType.Divide)
            {
                if (currentToken.Type == TokenType.Multiply)
                {
                    Eat(TokenType.Multiply);
                    result *= ParseFactor();
                }
                else if (currentToken.Type == TokenType.Divide)
                {
                    Eat(TokenType.Divide);
                    result /= ParseFactor();
                }
            }
            return result;

        }
        private double ParseExpression()
        {
            double result = ParseTerm();
            while (currentToken.Type == TokenType.Plus || currentToken.Type == TokenType.Minus)
            {
                if (currentToken.Type == TokenType.Plus)
                {
                    Eat(TokenType.Plus);
                    result += ParseTerm();
                }
                else if (currentToken.Type == TokenType.Minus)
                {
                    Eat(TokenType.Minus);
                    result -= ParseTerm();
                }
            }
            return result;
        }

        private double ParseFactor()
        {
            if (currentToken.Type == TokenType.Numer)
            {
                return ParseNumber();
            }
            else if (currentToken.Type == TokenType.Minus)
            {
                return ParseUnaryMius();
            }
            else if (currentToken.Type == TokenType.LeftParenteziz)
            {
                return ParseParenthezizes();
            }
            else
            {
                throw new Exception("Unknown Token" + currentToken.Type);
            }
        }

        public double ParseAll()
        {
            return ParseExpression();
        }
    }
}